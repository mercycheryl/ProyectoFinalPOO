package CineVentas.login;

import CineVentas.baseDatos.conectUsuarios.controlador.Servicio;
import CineVentas.baseDatos.conectUsuarios.modelo.Usuarios;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrearLogin extends JFrame {
    private JPanel JPanel1;
    private JTextField txtNombre;
    private JTextField txtUsuario;
    private JButton crearCuentaButton;
    private JButton regresarButton;
    private JPasswordField txtPassword1;
    private JTextField txtCedula;
    private JTextField txtTelefono;
    private JTextField txtDireccion;
    private JButton limpiarButton;
    private JPasswordField txtPassword2;
    private JTextField textCorreo;
    private JTextField textEdad;
    private JTextField txtCorreo;
    private JTextField txtEdad;
    private JComboBox cbGenero;

    public CrearLogin() {
        setTitle("CREAR UNA NUEVA CUENTA ");
        setSize(480, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(JPanel1);
        setLocationRelativeTo(null);

        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Login().setVisible(true);
                dispose();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        crearCuentaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearCuentaCliente();
            }
        });
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtUsuario.setText("");
        txtPassword1.setText("");
        txtPassword2.setText("");
        txtCedula.setText("");
        txtCorreo.setText("");
        txtEdad.setText("");
        cbGenero.setSelectedIndex(-1);
        txtTelefono.setText("");
        txtDireccion.setText("");
    }

    private void crearCuentaCliente() {
        // Validar campos obligatorios
        if (txtNombre.getText().isEmpty() || txtUsuario.getText().isEmpty() ||
                txtPassword1.getPassword().length == 0 || txtPassword2.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Nombre, usuario y contraseña son campos obligatorios",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validar que las contraseñas coincidan
        if (!String.valueOf(txtPassword1.getPassword()).equals(String.valueOf(txtPassword2.getPassword()))) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Crear objeto Usuario con los datos del formulario
            Usuarios nuevoCliente = new Usuarios(
                    txtNombre.getText(),
                    txtUsuario.getText(),
                    String.valueOf(txtPassword1.getPassword()),
                    "Cliente" // Tipo de usuario fijo como Cliente
            );

            // Establecer campos opcionales si están presentes
            if (!txtCedula.getText().isEmpty()) nuevoCliente.setCedula(txtCedula.getText());
            if (!txtCorreo.getText().isEmpty()) nuevoCliente.setCorreo(txtCorreo.getText());
            if (!txtEdad.getText().isEmpty()) {
                try {
                    nuevoCliente.setEdad(Integer.parseInt(txtEdad.getText()));
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "La edad debe ser un número",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            if (cbGenero.getSelectedItem() != null) {
                nuevoCliente.setGenero(cbGenero.getSelectedItem().toString());
            }
            if (!txtTelefono.getText().isEmpty()) nuevoCliente.setTelefono(txtTelefono.getText());
            if (!txtDireccion.getText().isEmpty()) nuevoCliente.setDireccion(txtDireccion.getText());

            // Insertar en la base de datos
            Servicio servicio = new Servicio();
            servicio.insertar(nuevoCliente);

            JOptionPane.showMessageDialog(this, "Cuenta creada exitosamente",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos();

            // Regresar al login
            new Login().setVisible(true);
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al crear la cuenta: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new CrearLogin().setVisible(true);
        });
    }
}