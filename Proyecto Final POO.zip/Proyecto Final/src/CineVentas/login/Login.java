package CineVentas.login;

import CineVentas.administrador.MenuAdministrador;
import CineVentas.baseDatos.conectUsuarios.controlador.Servicio;
import CineVentas.funcionario.MenuFuncionario;
import CineVentas.usuario.MenuUsuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Login extends JFrame {
    private JPanel jPanel1;
    private JComboBox<String> txtTipoUsuario;
    private JTextField txtUsuario;
    private JButton CuentaNuevaButton;
    private JButton iniciarSesionButton;
    private JCheckBox mostrarClaveCheckBox;
    private JPasswordField txtPassword;

    public Login() {
        setTitle("LOGIN");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(jPanel1);
        setLocationRelativeTo(null);


        // Botón para crear nueva cuenta
        CuentaNuevaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CrearLogin().setVisible(true);
                dispose();
            }
        });

        // Checkbox para mostrar/ocultar contraseña
        mostrarClaveCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (mostrarClaveCheckBox.isSelected()) {
                    txtPassword.setEchoChar((char) 0); // Mostrar texto
                } else {
                    txtPassword.setEchoChar('•'); // Ocultar con puntos
                }
            }
        });

        // Botón para iniciar sesión
        iniciarSesionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });
    }

    private void iniciarSesion() {
        String usuario = txtUsuario.getText().trim();
        String password = new String(txtPassword.getPassword());
        String tipoUsuario = txtTipoUsuario.getSelectedItem().toString();

        // Validar campos vacíos
        if (usuario.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Usuario y contraseña son obligatorios",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Servicio servicio = new Servicio();

            // Verificar credenciales
            if (validarCredenciales(servicio, usuario, password, tipoUsuario)) {
                JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);

                // Redirigir según tipo de usuario
                redirigirSegunTipoUsuario(tipoUsuario);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuario, contraseña o tipo de usuario incorrectos",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al iniciar sesión: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private boolean validarCredenciales(Servicio servicio, String usuario, String password, String tipoUsuario) {
        // Obtener contraseña real desde la base de datos
        String passwordReal = servicio.obtenerPassword(usuario);

        if (passwordReal == null) {
            return false; // Usuario no existe
        }

        // Verificar contraseña y tipo de usuario
        return password.equals(passwordReal) &&
                verificarTipoUsuario(servicio, usuario, tipoUsuario);
    }

    private boolean verificarTipoUsuario(Servicio servicio, String usuario, String tipoUsuario) {
        String tipoReal = servicio.obtenerTipoUsuario(usuario);
        return tipoUsuario.equalsIgnoreCase(tipoReal);
    }

    private void redirigirSegunTipoUsuario(String tipoUsuario) {
        switch (tipoUsuario) {
            case "Administrador":
                MenuAdministrador administrador = new MenuAdministrador();
                administrador.setVisible(true);
                break;
            case "Funcionario":
                MenuFuncionario funcionario = new MenuFuncionario();
                funcionario.setVisible(true);
                break;
            case "Cliente":
                MenuUsuario usuario = new MenuUsuario();
                usuario.setVisible(true);
                break;
            default:

        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}