package CineVentas.funcionario;

import CineVentas.login.Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuFuncionario extends  JFrame{
    private JPanel panel1;
    private JButton gestionFuncionesButton;
    private JButton cerrarButton;
    private JButton gestionPeliculasButton;
    private JButton gestionVentasButton;


    public MenuFuncionario() {
        setTitle("Menu Funcionario");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);
        cerrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login login = new Login();
                login.setVisible(true);
                setVisible(false);
            }
        });
        gestionFuncionesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SeccionFunciones funciones = new SeccionFunciones();
                funciones.setVisible(true);
                setVisible(false);
            }
        });
        gestionPeliculasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SeccionPeliculas peliculas = new SeccionPeliculas();
                peliculas.setVisible(true);
                setVisible(false);
            }
        });
        gestionVentasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SeccionVentas ventas = new SeccionVentas();
                ventas.setVisible(true);
                setVisible(false);
            }
        });
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MenuFuncionario().setVisible(true);
        });
    }
}
