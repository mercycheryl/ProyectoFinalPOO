package CineVentas.funcionario;

import CineVentas.administrador.MenuAdministrador;
import CineVentas.baseDatos.conectFunciones.controlador.Servicio;
import CineVentas.baseDatos.conectFunciones.modelo.Funciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class SeccionFunciones extends JFrame
{
    private JPanel panel1;
    private JTextField txtIdPeliculas;
    private JTextField txtNumeroSala;
    private JTextField txtAsientos;
    private JTextField txtFecha;
    private JButton regresarAlMenuButton;
    private JTextField textAsientosDisponibles;
    private JTextField textPrecio;
    private JTextField textHora;
    private JComboBox txtTipoSala;
    private JButton guardarButton;
    private JButton actualizarButton;
    private JButton eliminarButton;
    private JButton limpiarButton;
    private JTable table1;

    private DefaultTableModel model;
    private String clave;
    private Servicio controlador = new Servicio();
    private Object[] columns = {"ID", "ID Película", "Sala", "Asientos", "Tipo", "Fecha", "Hora", "Precio", "Disponibles"};
    private Object[] row = new Object[9];

    public SeccionFunciones() {
        setTitle("Seccion de Funciones");
        setSize(1024, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);


        // Configurar combobox
        txtTipoSala.setModel(new DefaultComboBoxModel<>(new String[]{"2D", "3D", "VIP"}));

        obtenerRegistroTabla();

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = table1.getSelectedRow();
                clave = model.getValueAt(i, 0).toString();
                txtIdPeliculas.setText(model.getValueAt(i, 1).toString());
                txtNumeroSala.setText(model.getValueAt(i, 2).toString());
                txtAsientos.setText(model.getValueAt(i, 3).toString());
                txtTipoSala.setSelectedItem(model.getValueAt(i, 4).toString());
                txtFecha.setText(model.getValueAt(i, 5).toString());
                textHora.setText(model.getValueAt(i, 6).toString());
                textPrecio.setText(model.getValueAt(i, 7).toString());
                textAsientosDisponibles.setText(model.getValueAt(i, 8).toString());
            }
        });

        guardarButton.addActionListener(e -> {
            Funciones funcion = new Funciones(
                    0, // ID temporal
                    Integer.parseInt(txtIdPeliculas.getText()),
                    Integer.parseInt(txtNumeroSala.getText()),
                    Integer.parseInt(txtAsientos.getText()),
                    txtTipoSala.getSelectedItem().toString(),
                    txtFecha.getText(),
                    textHora.getText(),
                    Double.parseDouble(textPrecio.getText()),
                    Integer.parseInt(textAsientosDisponibles.getText())
            );

            controlador.insertar(funcion);
            obtenerRegistroTabla();
        });

        actualizarButton.addActionListener(e -> {
            int id = Integer.parseInt(clave);
            Funciones funciones = new Funciones(
                    id,
                    Integer.parseInt(txtIdPeliculas.getText()),
                    Integer.parseInt(txtNumeroSala.getText()),
                    Integer.parseInt(txtAsientos.getText()),
                    txtTipoSala.getSelectedItem().toString(),
                    txtFecha.getText(),
                    textHora.getText(),
                    Double.parseDouble(textPrecio.getText()),
                    Integer.parseInt(textAsientosDisponibles.getText())
            );
            controlador.actualizar(funciones);
            obtenerRegistroTabla();
        });

        eliminarButton.addActionListener(e -> {
            int id = Integer.parseInt(clave);
            controlador.eliminar(id);
            obtenerRegistroTabla();
        });

        limpiarButton.addActionListener(e -> limpiarCampos());

        regresarAlMenuButton.addActionListener(e -> {
            MenuFuncionario menu = new MenuFuncionario();
            menu.setVisible(true);
            setVisible(false);
        });
    }

    private void obtenerRegistroTabla() {
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int fila, int columnas) {
                return false;
            }
        };
        model.setColumnIdentifiers(columns);

        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }

        Map<Integer, Funciones> mapa = controlador.seleccionarTodo();
        for (Map.Entry<Integer, Funciones> entry : mapa.entrySet()) {
            Funciones funcion = entry.getValue();
            row[0] = funcion.getIdFuncion();
            row[1] = funcion.getIdPelicula();
            row[2] = funcion.getNumeroSala();
            row[3] = funcion.getCantidadAsientos();
            row[4] = funcion.getTipoSala();
            row[5] = funcion.getFecha();
            row[6] = funcion.getHora();
            row[7] = funcion.getPrecio();
            row[8] = funcion.getAsientosDisponibles();
            model.addRow(row);
        }

        table1.setModel(model);
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtIdPeliculas.setText("");
        txtNumeroSala.setText("");
        txtAsientos.setText("");
        txtTipoSala.setSelectedIndex(0);
        txtFecha.setText("");
        textHora.setText("");
        textPrecio.setText("");
        textAsientosDisponibles.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SeccionFunciones().setVisible(true);
        });
    }
}
