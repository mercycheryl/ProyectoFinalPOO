package CineVentas.funcionario;

import CineVentas.baseDatos.conectPeliculas.controlador.Servicio;
import CineVentas.baseDatos.conectPeliculas.modelo.Peliculas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class SeccionPeliculas extends JFrame{
    private JTextField txtTitulo;
    private JTextField txtCategoria;
    private JTextField txtDuracion;
    private JTextField txtSinopsis;
    private JTextField textClasificacion;
    private JButton regreserAlMenuButton;
    private JComboBox comboBoxEstado;
    private JButton guardarButton;
    private JButton actualizarButton;
    private JButton eliminarButton;
    private JButton limpiarButton;
    private JTable table1;
    private JPanel panel1;

    private DefaultTableModel model;
    private String clave;
    private Servicio controlador = new Servicio();
    private Object[] columns = {"ID", "Título", "Categoría", "Duración", "Sinopsis", "Clasificación", "Estado"};
    private Object[] row = new Object[7];

    public SeccionPeliculas() {
        setTitle("Seccion de Películas");
        setSize(1024, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);

        // Configurar combobox
        comboBoxEstado.setModel(new DefaultComboBoxModel<>(new String[]{"disponible", "no disponible"}));

        obtenerRegistroTabla();

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = table1.getSelectedRow();
                clave = model.getValueAt(i, 0).toString();
                txtTitulo.setText(model.getValueAt(i, 1).toString());
                txtCategoria.setText(model.getValueAt(i, 2).toString());
                txtDuracion.setText(model.getValueAt(i, 3).toString());
                txtSinopsis.setText(model.getValueAt(i, 4).toString());  // Cargamos la sinopsis
                textClasificacion.setText(model.getValueAt(i, 5).toString());
                comboBoxEstado.setSelectedItem(model.getValueAt(i, 6).toString());
            }
        });

        guardarButton.addActionListener(e -> {
            Peliculas pelicula = new Peliculas(
                    0, // ID temporal
                    txtTitulo.getText(),
                    txtCategoria.getText(),
                    Integer.parseInt(txtDuracion.getText()),
                    txtSinopsis.getText(),
                    textClasificacion.getText(),
                    comboBoxEstado.getSelectedItem().toString()
            );

            controlador.insertar(pelicula);
            obtenerRegistroTabla();
        });

        actualizarButton.addActionListener(e -> {
            int id = Integer.parseInt(clave);
            Peliculas pelicula = new Peliculas(
                    id,
                    txtTitulo.getText(),
                    txtCategoria.getText(),
                    Integer.parseInt(txtDuracion.getText()),
                    txtSinopsis.getText(),
                    textClasificacion.getText(),
                    comboBoxEstado.getSelectedItem().toString()
            );
            controlador.actualizar(pelicula);
            obtenerRegistroTabla();
        });

        eliminarButton.addActionListener(e -> {
            int id = Integer.parseInt(clave);
            controlador.eliminar(id);
            obtenerRegistroTabla();
        });

        limpiarButton.addActionListener(e -> limpiarCampos());

        regreserAlMenuButton.addActionListener(e -> {
            MenuFuncionario menu = new MenuFuncionario();
            menu.setVisible(true);
            setVisible(false);
        });
    }

    private void obtenerRegistroTabla() {
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int fila, int columnas) {
                return false;
            }
        };
        model.setColumnIdentifiers(columns);

        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }

        Map<Integer, Peliculas> mapa = controlador.seleccionarTodo();
        for (Map.Entry<Integer, Peliculas> entry : mapa.entrySet()) {
            Peliculas pelicula = entry.getValue();
            row[0] = pelicula.getIdPelicula();
            row[1] = pelicula.getTitulo();
            row[2] = pelicula.getCategoria();
            row[3] = pelicula.getDuracion();
            row[4] = pelicula.getSinopsis();  // Añadimos la sinopsis
            row[5] = pelicula.getClasificacion();
            row[6] = pelicula.getEstado();
            model.addRow(row);
        }

        table1.setModel(model);
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtTitulo.setText("");
        txtCategoria.setText("");
        txtDuracion.setText("");
        txtSinopsis.setText("");
        textClasificacion.setText("");
        comboBoxEstado.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SeccionPeliculas().setVisible(true);
        });
    }
}
