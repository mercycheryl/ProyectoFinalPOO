package CineVentas.baseDatos.conectUsuarios.controlador;

import CineVentas.baseDatos.conectUsuarios.modelo.Conexion;
import CineVentas.baseDatos.conectUsuarios.modelo.CrudUsuarios;
import CineVentas.baseDatos.conectUsuarios.modelo.ImplUsuarios;
import CineVentas.baseDatos.conectUsuarios.modelo.Usuarios;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class Servicio {
    private CrudUsuarios implementacion = new ImplUsuarios();
    Conexion conexion = new Conexion();

    public Map<Integer, Usuarios> seleccionarTodo() {
        return implementacion.seleccionarTodo();
    }

    public void insertar(Usuarios usuarios) {
        implementacion.insertar(usuarios);
    }

    public void actualizar(Usuarios usuarios) {
        implementacion.actualizar(usuarios);
    }

    public void eliminar(int id) {
        if (JOptionPane.showConfirmDialog(null,
                "¿Estás seguro que deseas eliminar este usuario?",
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            implementacion.eliminar(id);
        }
    }

    public String obtenerPassword(String usuario) {
        String password = null;
        String sql = "SELECT contraseNIA FROM usuarios WHERE usuario = ?";

        try (Connection conn = conexion.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario); // Cambiado de 2 a 1
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                password = rs.getString("contraseNIA");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Error al obtener contraseña: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return password;
    }

    public String obtenerTipoUsuario(String usuario) {
        String tipoUsuario = null;
        String sql = "SELECT tipo_usuario FROM usuarios WHERE usuario = ?";

        try (Connection conn = conexion.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                tipoUsuario = rs.getString("tipo_usuario");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Error al obtener tipo de usuario: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return tipoUsuario;
    }

    public boolean verificarCredenciales(String usuario, String password, String tipoUsuario) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE usuario = ? AND contrasenia = ? AND tipo_usuario = ?";

        try (Connection conn = conexion.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario);
            pstmt.setString(2, password);
            pstmt.setString(3, tipoUsuario);
            ResultSet rs = pstmt.executeQuery();

            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}