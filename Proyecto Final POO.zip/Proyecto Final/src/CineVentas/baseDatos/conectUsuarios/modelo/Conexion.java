package CineVentas.baseDatos.conectUsuarios.modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion
{
    private File archivo = null;
    private FileReader fr = null;
    private BufferedReader br = null;

    public Connection conectar() {
        // Cambiar la ruta para que apunte a cineVentas.db
        String url = "jdbc:sqlite:" + new File("C:/Users/ACER/Desktop/Pailland/Programacion Orientada a Objetos/ProyectoSegundoBimestre/OneDrive_2025-07-24/Proyecto Final/src/CineVentas/baseDatos/cineVentas.db").getAbsolutePath();
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(url);
            System.out.println("Conexión establecida con la base de datos");
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
        return conn;
    }

    public static void main(String[] args) {
        Conexion con = new Conexion();
        con.conectar();

    }
}
