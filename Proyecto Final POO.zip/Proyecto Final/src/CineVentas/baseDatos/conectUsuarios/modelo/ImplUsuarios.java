package CineVentas.baseDatos.conectUsuarios.modelo;

import javax.swing.*;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplUsuarios implements CrudUsuarios {
    private final String SELECT = "SELECT * from usuarios";
    private final String SELECT_BY_ID = "SELECT * from usuarios where id_usuario = ?";
    private final String INSERT = "INSERT INTO usuarios(nombre, usuario, contrasenia, tipo_usuario, cedula, correo, edad, genero, telefono, direccion) VALUES (?,?,?,?,?,?,?,?,?,?)";
    private final String UPDATE = "UPDATE usuarios SET nombre = ?, usuario = ?, contrasenia = ?, tipo_usuario = ?, cedula = ?, correo = ?, edad = ?, genero = ?, telefono = ?, direccion = ? WHERE id_usuario = ?";
    private final String DELETE = "DELETE FROM usuarios WHERE id_usuario = ?";

    private Connection conn = null;

    private Connection conectar() {
        Conexion conexion = new Conexion();
        conn = conexion.conectar();
        return conn;
    }

    @Override
    public Map<Integer, Usuarios> seleccionarTodo() {
        Map<Integer, Usuarios> map = new LinkedHashMap<>();

        try {
            Connection conn = this.conectar();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SELECT);
            while (rs.next()) {
                Usuarios usuarios = new Usuarios(
                        rs.getInt("id_usuario"),
                        rs.getString("nombre"),
                        rs.getString("usuario"),
                        rs.getString("contrasenia"),
                        rs.getString("tipo_usuario"),
                        rs.getString("cedula"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        rs.getString("genero"),
                        rs.getString("telefono"),
                        rs.getString("direccion")
                );
                map.put(rs.getInt("id_usuario"), usuarios);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return map;
    }

    @Override
    public Usuarios buscar(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuarios usuarios = null;

        try {
            conn = this.conectar();
            stmt = conn.prepareStatement(SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                usuarios = new Usuarios(
                        rs.getInt("id_usuario"),
                        rs.getString("nombre"),
                        rs.getString("usuario"),
                        rs.getString("contrasenia"),
                        rs.getString("tipo_usuario"),
                        rs.getString("cedula"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        rs.getString("genero"),
                        rs.getString("telefono"),
                        rs.getString("direccion")
                );
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return usuarios;
    }

    @Override
    public void insertar(Usuarios usuarios) {
        try {
            Connection conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(INSERT);
            pstmt.setString(1, usuarios.getNombre());
            pstmt.setString(2, usuarios.getUsuario());
            pstmt.setString(3, usuarios.getContrasenia());
            pstmt.setString(4, usuarios.getTipoUsuario());
            pstmt.setString(5, usuarios.getCedula());
            pstmt.setString(6, usuarios.getCorreo());
            pstmt.setInt(7, usuarios.getEdad());
            pstmt.setString(8, usuarios.getGenero());
            pstmt.setString(9, usuarios.getTelefono());
            pstmt.setString(10, usuarios.getDireccion());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actualizar(Usuarios usuarios) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, usuarios.getNombre());
            pstmt.setString(2, usuarios.getUsuario());
            pstmt.setString(3, usuarios.getContrasenia());
            pstmt.setString(4, usuarios.getTipoUsuario());
            pstmt.setString(5, usuarios.getCedula());
            pstmt.setString(6, usuarios.getCorreo());
            pstmt.setInt(7, usuarios.getEdad());
            pstmt.setString(8, usuarios.getGenero());
            pstmt.setString(9, usuarios.getTelefono());
            pstmt.setString(10, usuarios.getDireccion());
            pstmt.setInt(11, usuarios.getIdUsuario());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}