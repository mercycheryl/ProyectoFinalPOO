package CineVentas.baseDatos.conectUsuarios.modelo;

import java.util.Map;

public interface CrudUsuarios {
    // Mostrar todos
    public Map<Integer, Usuarios> seleccionarTodo();

    // Mostrar Uno
    public Usuarios buscar(int id);

    // Insertar
    public void insertar(Usuarios usuarios);

    // Actualizar
    public void actualizar(Usuarios usuarios);

    // Eliminar
    public void eliminar(int id);
}