package CineVentas.baseDatos.conectUsuarios.modelo;

public class Usuarios {
    private int idUsuario;
    private String nombre;
    private String usuario;
    private String contrasenia;
    private String tipoUsuario;
    private String cedula;
    private String correo;
    private int edad;
    private String genero;
    private String telefono;
    private String direccion;

    // Constructores
    public Usuarios(String nombre, String usuario, String contrasenia, String tipoUsuario) {
        this.nombre = nombre;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.tipoUsuario = tipoUsuario;
    }

    public Usuarios(int idUsuario, String nombre, String usuario, String contrasenia,
                   String tipoUsuario, String cedula, String correo, int edad,
                   String genero, String telefono, String direccion) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.tipoUsuario = tipoUsuario;
        this.cedula = cedula;
        this.correo = correo;
        this.edad = edad;
        this.genero = genero;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    // Getters y Setters
    public int getIdUsuario() { return idUsuario; }
    public String getNombre() { return nombre; }
    public String getUsuario() { return usuario; }
    public String getContrasenia() { return contrasenia; }
    public String getTipoUsuario() { return tipoUsuario; }
    public String getCedula() { return cedula; }
    public String getCorreo() { return correo; }
    public int getEdad() { return edad; }
    public String getGenero() { return genero; }
    public String getTelefono() { return telefono; }
    public String getDireccion() { return direccion; }

    public void setCedula(String cedula) { this.cedula = cedula; }
    public void setCorreo(String correo) { this.correo = correo; }
    public void setEdad(int edad) { this.edad = edad; }
    public void setGenero(String genero) { this.genero = genero; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    @Override
    public String toString() {
        return "Usuario id=" + idUsuario + ", nombre=" + nombre + ", usuario=" + usuario +
                ", tipo=" + tipoUsuario;
    }
}