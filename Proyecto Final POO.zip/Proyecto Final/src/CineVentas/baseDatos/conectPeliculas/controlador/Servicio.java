package CineVentas.baseDatos.conectPeliculas.controlador;

import CineVentas.baseDatos.conectPeliculas.modelo.Conexion;
import CineVentas.baseDatos.conectPeliculas.modelo.CrudPeliculas;
import CineVentas.baseDatos.conectPeliculas.modelo.ImplPeliculas;
import CineVentas.baseDatos.conectPeliculas.modelo.Peliculas;

import javax.swing.*;
import java.util.Map;

public class Servicio {
    private CrudPeliculas implementacion = new ImplPeliculas();
    Conexion conexion = new Conexion();

    public Map<Integer, Peliculas> seleccionarTodo() {
        return implementacion.seleccionarTodo();
    }

    public void insertar(Peliculas pelicula) {
        implementacion.insertar(pelicula);
    }

    public void actualizar(Peliculas pelicula) {
        implementacion.actualizar(pelicula);
    }

    public void eliminar(int id) {
        if (JOptionPane.showConfirmDialog(null,
                "¿Estás seguro que deseas eliminar esta película?",
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            implementacion.eliminar(id);
        }
    }
}