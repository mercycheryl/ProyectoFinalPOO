package CineVentas.baseDatos.conectPeliculas.modelo;

import java.util.Map;

public interface CrudPeliculas {
    // Mostrar todos
    public Map<Integer, Peliculas> seleccionarTodo();

    // Mostrar Uno
    public Peliculas buscar(int id);

    // Insertar
    public void insertar(Peliculas pelicula);

    // Actualizar
    public void actualizar(Peliculas pelicula);

    // Eliminar
    public void eliminar(int id);
}