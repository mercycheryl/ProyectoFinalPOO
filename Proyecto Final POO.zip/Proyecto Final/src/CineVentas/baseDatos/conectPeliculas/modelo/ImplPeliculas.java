package CineVentas.baseDatos.conectPeliculas.modelo;

import javax.swing.*;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplPeliculas implements CrudPeliculas {
    private final String SELECT = "SELECT * from peliculas";
    private final String SELECT_BY_ID = "SELECT * from peliculas where id_pelicula = ?";
    private final String INSERT = "INSERT INTO peliculas(titulo, categoria, duracion, sinopsis, clasificacion, estado) VALUES (?,?,?,?,?,?)";
    private final String UPDATE = "UPDATE peliculas SET titulo = ?, categoria = ?, duracion = ?, sinopsis = ?, clasificacion = ?, estado = ? WHERE id_pelicula = ?";
    private final String DELETE = "DELETE FROM peliculas WHERE id_pelicula = ?";

    private Connection conn = null;

    private Connection conectar() {
        Conexion conexion = new Conexion();
        conn = conexion.conectar();
        return conn;
    }

    @Override
    public Map<Integer, Peliculas> seleccionarTodo() {
        Map<Integer, Peliculas> map = new LinkedHashMap<>();

        try {
            Connection conn = this.conectar();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SELECT);
            while (rs.next()) {
                Peliculas pelicula = new Peliculas(
                        rs.getInt("id_pelicula"),
                        rs.getString("titulo"),
                        rs.getString("categoria"),
                        rs.getInt("duracion"),
                        rs.getString("sinopsis"),
                        rs.getString("clasificacion"),
                        rs.getString("estado")
                );
                map.put(rs.getInt("id_pelicula"), pelicula);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return map;
    }

    @Override
    public Peliculas buscar(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Peliculas pelicula = null;

        try {
            conn = this.conectar();
            stmt = conn.prepareStatement(SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                pelicula = new Peliculas(
                        rs.getInt("id_pelicula"),
                        rs.getString("titulo"),
                        rs.getString("categoria"),
                        rs.getInt("duracion"),
                        rs.getString("sinopsis"),
                        rs.getString("clasificacion"),
                        rs.getString("estado")
                );
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return pelicula;
    }

    @Override
    public void insertar(Peliculas pelicula) {
        try {
            Connection conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(INSERT);
            pstmt.setString(1, pelicula.getTitulo());
            pstmt.setString(2, pelicula.getCategoria());
            pstmt.setInt(3, pelicula.getDuracion());
            pstmt.setString(4, pelicula.getSinopsis());
            pstmt.setString(5, pelicula.getClasificacion());
            pstmt.setString(6, pelicula.getEstado());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actualizar(Peliculas pelicula) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, pelicula.getTitulo());
            pstmt.setString(2, pelicula.getCategoria());
            pstmt.setInt(3, pelicula.getDuracion());
            pstmt.setString(4, pelicula.getSinopsis());
            pstmt.setString(5, pelicula.getClasificacion());
            pstmt.setString(6, pelicula.getEstado());
            pstmt.setInt(7, pelicula.getIdPelicula());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}