package CineVentas.baseDatos.conectPeliculas.modelo;

public class Peliculas {
    private int idPelicula;
    private String titulo;
    private String categoria;
    private int duracion;
    private String sinopsis;
    private String clasificacion;
    private String estado;

    // Constructores
    public Peliculas(String titulo, String categoria, int duracion, String sinopsis, String clasificacion, String estado) {
        this.titulo = titulo;
        this.categoria = categoria;
        this.duracion = duracion;
        this.sinopsis = sinopsis;
        this.clasificacion = clasificacion;
        this.estado = estado;
    }

    public Peliculas(int idPelicula, String titulo, String categoria, int duracion, String sinopsis, String clasificacion, String estado) {
        this.idPelicula = idPelicula;
        this.titulo = titulo;
        this.categoria = categoria;
        this.duracion = duracion;
        this.sinopsis = sinopsis;
        this.clasificacion = clasificacion;
        this.estado = estado;
    }

    // Getters y Setters
    public int getIdPelicula() { return idPelicula; }
    public String getTitulo() { return titulo; }
    public String getCategoria() { return categoria; }
    public int getDuracion() { return duracion; }
    public String getSinopsis() { return sinopsis; }
    public String getClasificacion() { return clasificacion; }
    public String getEstado() { return estado; }

    @Override
    public String toString() {
        return "Pelicula id=" + idPelicula + ", titulo=" + titulo + ", categoria=" + categoria;
    }
}