package CineVentas.baseDatos.conectVentas.controlador;

import CineVentas.baseDatos.conectVentas.modelo.Conexion;
import CineVentas.baseDatos.conectVentas.modelo.CrudVentas;
import CineVentas.baseDatos.conectVentas.modelo.ImplVentas;
import CineVentas.baseDatos.conectVentas.modelo.Ventas;

import javax.swing.*;
import java.util.Map;

public class Servicio {
    private CrudVentas implementacion = new ImplVentas();
    Conexion conexion = new Conexion();

    public Map<Integer, Ventas> seleccionarTodo() {
        return implementacion.seleccionarTodo();
    }

    public Ventas buscar(int id) {
        return implementacion.buscar(id);
    }

    public void insertar(Ventas venta) {
        implementacion.insertar(venta);
    }

    public void actualizar(Ventas venta) {
        implementacion.actualizar(venta);
    }

    public void eliminar(int id) {
        if (JOptionPane.showConfirmDialog(null,
                "¿Estás seguro que deseas eliminar esta venta?",
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            implementacion.eliminar(id);
        }
    }

    public double calcularTotal(int idFuncion, int cantidadBoletos) {
        double precio = implementacion.obtenerPrecioFuncion(idFuncion);
        return precio * cantidadBoletos;
    }
}