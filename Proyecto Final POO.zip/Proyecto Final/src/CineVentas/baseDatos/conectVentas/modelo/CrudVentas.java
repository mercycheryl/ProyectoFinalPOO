package CineVentas.baseDatos.conectVentas.modelo;

import java.util.Map;

public interface CrudVentas {
    Map<Integer, Ventas> seleccionarTodo();
    Ventas buscar(int id);
    void insertar(Ventas venta);
    void actualizar(Ventas venta);
    void eliminar(int id);
    double obtenerPrecioFuncion(int idFuncion);
}