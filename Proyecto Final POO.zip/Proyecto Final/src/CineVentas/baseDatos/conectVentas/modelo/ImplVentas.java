package CineVentas.baseDatos.conectVentas.modelo;

import javax.swing.*;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplVentas implements CrudVentas {
    private final String INSERT = "INSERT INTO ventas(id_funcion, id_usuario_vendedor, id_usuario_cliente, cantidad_boletos, total) VALUES (?,?,?,?,?)";
    private final String UPDATE = "UPDATE ventas SET id_funcion = ?, id_usuario_vendedor = ?, id_usuario_cliente = ?, cantidad_boletos = ?, total = ? WHERE id_venta = ?";
    private final String DELETE = "DELETE FROM ventas WHERE id_venta = ?";
    private final String PRECIO_FUNCION = "SELECT precio FROM funciones WHERE id_funcion = ?";

    // Modificar las consultas SQL para incluir la hora
    private final String SELECT = "SELECT v.*, strftime('%H:%M', v.fecha_venta) as hora FROM ventas v";
    private final String SELECT_BY_ID = "SELECT v.*, strftime('%H:%M', v.fecha_venta) as hora FROM ventas v WHERE id_venta = ?";


    private Connection conn = null;

    private Connection conectar() {
        Conexion conexion = new Conexion();
        conn = conexion.conectar();
        return conn;
    }

    @Override
    public Map<Integer, Ventas> seleccionarTodo() {
        Map<Integer, Ventas> map = new LinkedHashMap<>();
        try {
            Connection conn = this.conectar();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SELECT);
            while (rs.next()) {
                Ventas venta = new Ventas();
                venta.setIdVenta(rs.getInt("id_venta"));
                venta.setIdFuncion(rs.getInt("id_funcion"));
                venta.setIdUsuarioVendedor(rs.getInt("id_usuario_vendedor"));
                venta.setIdUsuarioCliente(rs.getInt("id_usuario_cliente"));
                venta.setCantidadBoletos(rs.getInt("cantidad_boletos"));
                venta.setTotal(rs.getDouble("total"));
                venta.setFechaVenta(rs.getString("fecha_venta"));
                venta.setHoraVenta(rs.getString("hora"));
                map.put(venta.getIdVenta(), venta);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return map;
    }

    @Override
    public Ventas buscar(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Ventas venta = null;
        try {
            conn = this.conectar();
            stmt = conn.prepareStatement(SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                venta = new Ventas();
                venta.setIdVenta(rs.getInt("id_venta"));
                venta.setIdFuncion(rs.getInt("id_funcion"));
                venta.setIdUsuarioVendedor(rs.getInt("id_usuario_vendedor"));
                venta.setIdUsuarioCliente(rs.getInt("id_usuario_cliente"));
                venta.setCantidadBoletos(rs.getInt("cantidad_boletos"));
                venta.setTotal(rs.getDouble("total"));
                venta.setFechaVenta(rs.getString("fecha_venta"));
                venta.setHoraVenta(rs.getString("hora"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return venta;
    }

    @Override
    public void insertar(Ventas venta) {
        try {
            Connection conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(INSERT);
            pstmt.setInt(1, venta.getIdFuncion());
            pstmt.setInt(2, venta.getIdUsuarioVendedor());
            pstmt.setInt(3, venta.getIdUsuarioCliente());
            pstmt.setInt(4, venta.getCantidadBoletos());
            pstmt.setDouble(5, venta.getTotal());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actualizar(Ventas venta) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(UPDATE);
            pstmt.setInt(1, venta.getIdFuncion());
            pstmt.setInt(2, venta.getIdUsuarioVendedor());
            pstmt.setInt(3, venta.getIdUsuarioCliente());
            pstmt.setInt(4, venta.getCantidadBoletos());
            pstmt.setDouble(5, venta.getTotal());
            pstmt.setInt(6, venta.getIdVenta());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    @Override
    public double obtenerPrecioFuncion(int idFuncion) {
        double precio = 0;
        try (Connection conn = this.conectar();
             PreparedStatement pstmt = conn.prepareStatement(PRECIO_FUNCION)) {
            pstmt.setInt(1, idFuncion);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                precio = rs.getDouble("precio");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener precio: " + e.getMessage());
        }
        return precio;
    }
}