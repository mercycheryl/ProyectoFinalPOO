package CineVentas.baseDatos.conectVentas.modelo;

public class Ventas {
    private int idVenta;
    private int idFuncion;
    private int idUsuarioVendedor;
    private int idUsuarioCliente;
    private int cantidadBoletos;
    private double total;
    private String fechaVenta;
    private String horaVenta;

    public Ventas() {}

    public Ventas(int idFuncion, int idUsuarioVendedor, int idUsuarioCliente,
                  int cantidadBoletos, double total) {
        this.idFuncion = idFuncion;
        this.idUsuarioVendedor = idUsuarioVendedor;
        this.idUsuarioCliente = idUsuarioCliente;
        this.cantidadBoletos = cantidadBoletos;
        this.total = total;
    }

    // Getters y Setters
    public int getIdVenta() { return idVenta; }
    public void setIdVenta(int idVenta) { this.idVenta = idVenta; }
    public int getIdFuncion() { return idFuncion; }
    public void setIdFuncion(int idFuncion) { this.idFuncion = idFuncion; }
    public int getIdUsuarioVendedor() { return idUsuarioVendedor; }
    public void setIdUsuarioVendedor(int idUsuarioVendedor) { this.idUsuarioVendedor = idUsuarioVendedor; }
    public int getIdUsuarioCliente() { return idUsuarioCliente; }
    public void setIdUsuarioCliente(int idUsuarioCliente) { this.idUsuarioCliente = idUsuarioCliente; }
    public int getCantidadBoletos() { return cantidadBoletos; }
    public void setCantidadBoletos(int cantidadBoletos) { this.cantidadBoletos = cantidadBoletos; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    public String getFechaVenta() { return fechaVenta; }
    public void setFechaVenta(String fechaVenta) { this.fechaVenta = fechaVenta; }

    public String getHoraVenta() { return horaVenta; }
    public void setHoraVenta(String horaVenta) { this.horaVenta = horaVenta; }
}