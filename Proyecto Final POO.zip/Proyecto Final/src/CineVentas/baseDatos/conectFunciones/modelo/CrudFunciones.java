package CineVentas.baseDatos.conectFunciones.modelo;

import java.util.Map;

public interface CrudFunciones {
    // Mostrar todos
    public Map<Integer, Funciones> seleccionarTodo();

    // Mostrar Uno
    public Funciones buscar(int id);

    // Insertar
    public void insertar(Funciones funcion);

    // Actualizar
    public void actualizar(Funciones funcion);

    // Eliminar
    public void eliminar(int id);
}