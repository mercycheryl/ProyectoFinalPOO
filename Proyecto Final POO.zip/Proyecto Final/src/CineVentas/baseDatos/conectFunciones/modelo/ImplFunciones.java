package CineVentas.baseDatos.conectFunciones.modelo;

import javax.swing.*;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplFunciones implements CrudFunciones {
    private final String SELECT = "SELECT * from funciones";
    private final String SELECT_BY_ID = "SELECT * from funciones where id_funcion = ?";
    private final String INSERT = "INSERT INTO funciones(id_pelicula, numero_sala, cantidad_asientos, tipo_sala, fecha, hora, precio, asientos_disponibles) VALUES (?,?,?,?,?,?,?,?)";
    private final String UPDATE = "UPDATE funciones SET id_pelicula = ?, numero_sala = ?, cantidad_asientos = ?, tipo_sala = ?, fecha = ?, hora = ?, precio = ?, asientos_disponibles = ? WHERE id_funcion = ?";
    private final String DELETE = "DELETE FROM funciones WHERE id_funcion = ?";

    private Connection conn = null;

    private Connection conectar() {
        Conexion conexion = new Conexion();
        conn = conexion.conectar();
        return conn;
    }

    @Override
    public Map<Integer, Funciones> seleccionarTodo() {
        Map<Integer, Funciones> map = new LinkedHashMap<>();

        try {
            Connection conn = this.conectar();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SELECT);
            while (rs.next()) {
                Funciones funcion = new Funciones(
                        rs.getInt("id_funcion"),
                        rs.getInt("id_pelicula"),
                        rs.getInt("numero_sala"),
                        rs.getInt("cantidad_asientos"),
                        rs.getString("tipo_sala"),
                        rs.getString("fecha"),
                        rs.getString("hora"),
                        rs.getDouble("precio"),
                        rs.getInt("asientos_disponibles")
                );
                map.put(rs.getInt("id_funcion"), funcion);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return map;
    }

    @Override
    public Funciones buscar(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Funciones funcion = null;

        try {
            conn = this.conectar();
            stmt = conn.prepareStatement(SELECT_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                funcion = new Funciones(
                        rs.getInt("id_funcion"),
                        rs.getInt("id_pelicula"),
                        rs.getInt("numero_sala"),
                        rs.getInt("cantidad_asientos"),
                        rs.getString("tipo_sala"),
                        rs.getString("fecha"),
                        rs.getString("hora"),
                        rs.getDouble("precio"),
                        rs.getInt("asientos_disponibles")
                );
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return funcion;
    }

    @Override
    public void insertar(Funciones funcion) {
        try {
            Connection conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(INSERT);
            pstmt.setInt(1, funcion.getIdPelicula());
            pstmt.setInt(2, funcion.getNumeroSala());
            pstmt.setInt(3, funcion.getCantidadAsientos());
            pstmt.setString(4, funcion.getTipoSala());
            pstmt.setString(5, funcion.getFecha());
            pstmt.setString(6, funcion.getHora());
            pstmt.setDouble(7, funcion.getPrecio());
            pstmt.setInt(8, funcion.getAsientosDisponibles());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void actualizar(Funciones funcion) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(UPDATE);
            pstmt.setInt(1, funcion.getIdPelicula());
            pstmt.setInt(2, funcion.getNumeroSala());
            pstmt.setInt(3, funcion.getCantidadAsientos());
            pstmt.setString(4, funcion.getTipoSala());
            pstmt.setString(5, funcion.getFecha());
            pstmt.setString(6, funcion.getHora());
            pstmt.setDouble(7, funcion.getPrecio());
            pstmt.setInt(8, funcion.getAsientosDisponibles());
            pstmt.setInt(9, funcion.getIdFuncion());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            conn = this.conectar();
            PreparedStatement pstmt = conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}