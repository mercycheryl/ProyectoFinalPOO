package CineVentas.baseDatos.conectFunciones.modelo;

public class Funciones {
    private int idFuncion;
    private int idPelicula;
    private int numeroSala;
    private int cantidadAsientos;
    private String tipoSala;
    private String fecha;
    private String hora;
    private double precio;
    private int asientosDisponibles;

    // Constructor completo
    public Funciones(int idFuncion, int idPelicula, int numeroSala, int cantidadAsientos,
                     String tipoSala, String fecha, String hora, double precio,
                     int asientosDisponibles) {
        this.idFuncion = idFuncion;
        this.idPelicula = idPelicula;
        this.numeroSala = numeroSala;
        this.cantidadAsientos = cantidadAsientos;
        this.tipoSala = tipoSala;
        this.fecha = fecha;
        this.hora = hora;
        this.precio = precio;
        this.asientosDisponibles = asientosDisponibles;
    }

    // Getters
    public int getIdFuncion() { return idFuncion; }
    public int getIdPelicula() { return idPelicula; }
    public int getNumeroSala() { return numeroSala; }
    public int getCantidadAsientos() { return cantidadAsientos; }
    public String getTipoSala() { return tipoSala; }
    public String getFecha() { return fecha; }
    public String getHora() { return hora; }
    public double getPrecio() { return precio; }
    public int getAsientosDisponibles() { return asientosDisponibles; }

    @Override
    public String toString() {
        return "Función ID: " + idFuncion + ", Sala: " + numeroSala +
                ", Tipo: " + tipoSala + ", Fecha: " + fecha + ", Hora: " + hora;
    }
}