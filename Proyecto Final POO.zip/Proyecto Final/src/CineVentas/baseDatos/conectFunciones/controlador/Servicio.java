package CineVentas.baseDatos.conectFunciones.controlador;

import CineVentas.baseDatos.conectFunciones.modelo.Conexion;
import CineVentas.baseDatos.conectFunciones.modelo.CrudFunciones;
import CineVentas.baseDatos.conectFunciones.modelo.ImplFunciones;
import CineVentas.baseDatos.conectFunciones.modelo.Funciones;

import javax.swing.*;
import java.util.Map;

public class Servicio {
    private CrudFunciones implementacion = new ImplFunciones();
    Conexion conexion = new Conexion();

    public Map<Integer, Funciones> seleccionarTodo() {
        return implementacion.seleccionarTodo();
    }

    public void insertar(Funciones funcion) {
        implementacion.insertar(funcion);
    }

    public void actualizar(Funciones funcion) {
        implementacion.actualizar(funcion);
    }

    public void eliminar(int id) {
        if (JOptionPane.showConfirmDialog(null,
                "¿Estás seguro que deseas eliminar esta función?",
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            implementacion.eliminar(id);
        }
    }

    public Funciones buscar(int id) {
        return implementacion.buscar(id);
    }
}