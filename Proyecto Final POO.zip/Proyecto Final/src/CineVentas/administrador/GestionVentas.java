package CineVentas.administrador;

import CineVentas.baseDatos.conectVentas.controlador.Servicio;
import CineVentas.baseDatos.conectVentas.modelo.Ventas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class GestionVentas extends JFrame
{
    private JPanel reportes;
    private JTable table1;
    private JTextField txtIdFuncion;
    private JTextField txtIdVendedor;
    private JTextField txtIdCliente;
    private JTextField txtHora;
    private JTextField txtCantidad;
    private JTextField txtFecha;
    private JButton guardarButton;
    private JButton actualizarButton;
    private JButton limpiarButton;
    private JButton eliminarButton;
    private JButton regresarAlMenuButton;
    private JLabel txtTotal;
    private JButton calcularButton;

    private DefaultTableModel model;
    private String clave;
    private Servicio controlador = new Servicio();
    private Object[] columns = {"ID Venta", "ID Función", "ID Vendedor", "ID Cliente", "Cantidad", "Total", "Fecha", "Hora"};
    private Object[] row = new Object[8];


    public GestionVentas() {
        setTitle("Detalles de Venta");
        setSize(1024, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(reportes);
        setLocationRelativeTo(null);

        obtenerRegistroTabla();


        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = table1.getSelectedRow();
                clave = model.getValueAt(i, 0).toString();
                txtIdFuncion.setText(model.getValueAt(i, 1).toString());
                txtIdVendedor.setText(model.getValueAt(i, 2).toString());
                txtIdCliente.setText(model.getValueAt(i, 3).toString());
                txtCantidad.setText(model.getValueAt(i, 4).toString());
                txtTotal.setText(model.getValueAt(i, 5).toString());
                txtFecha.setText(model.getValueAt(i, 6).toString());
                txtHora.setText(model.getValueAt(i, 7).toString());
            }
        });

        calcularButton.addActionListener(e -> calcularTotal());

        guardarButton.addActionListener(e -> {
            try {
                Ventas venta = new Ventas(
                        Integer.parseInt(txtIdFuncion.getText()),
                        Integer.parseInt(txtIdVendedor.getText()),
                        Integer.parseInt(txtIdCliente.getText()),
                        Integer.parseInt(txtCantidad.getText()),
                        Double.parseDouble(txtTotal.getText().replace("$", ""))
                );
                controlador.insertar(venta);
                obtenerRegistroTabla();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        actualizarButton.addActionListener(e -> {
            try {
                Ventas venta = new Ventas(
                        Integer.parseInt(txtIdFuncion.getText()),
                        Integer.parseInt(txtIdVendedor.getText()),
                        Integer.parseInt(txtIdCliente.getText()),
                        Integer.parseInt(txtCantidad.getText()),
                        Double.parseDouble(txtTotal.getText().replace("$", ""))
                );
                venta.setIdVenta(Integer.parseInt(clave));
                controlador.actualizar(venta);
                obtenerRegistroTabla();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        eliminarButton.addActionListener(e -> {
            if (!clave.isEmpty()) {
                controlador.eliminar(Integer.parseInt(clave));
                obtenerRegistroTabla();
            }
        });

        limpiarButton.addActionListener(e -> limpiarCampos());

        regresarAlMenuButton.addActionListener(e -> {
            MenuAdministrador menu = new MenuAdministrador();
            menu.setVisible(true);
            setVisible(false);
        });
    }

    private void calcularTotal() {
        try {
            int idFuncion = Integer.parseInt(txtIdFuncion.getText());
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double total = controlador.calcularTotal(idFuncion, cantidad);
            txtTotal.setText(String.format("$%.2f", total));
        } catch (NumberFormatException e) {
            // No hacer nada si los datos no son válidos aún
        }
    }

    private void obtenerRegistroTabla() {
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int fila, int columnas) {
                return false;
            }
        };
        model.setColumnIdentifiers(columns);

        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }

        Map<Integer, Ventas> mapa = controlador.seleccionarTodo();
        for (Map.Entry<Integer, Ventas> entry : mapa.entrySet()) {
            Ventas venta = entry.getValue();
            row[0] = venta.getIdVenta();
            row[1] = venta.getIdFuncion();
            row[2] = venta.getIdUsuarioVendedor();
            row[3] = venta.getIdUsuarioCliente();
            row[4] = venta.getCantidadBoletos();
            row[5] = String.format("$%.2f", venta.getTotal());
            row[6] = venta.getFechaVenta();
            row[7] = venta.getHoraVenta();
            model.addRow(row);
        }
        table1.setModel(model);
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtIdFuncion.setText("");
        txtIdVendedor.setText("");
        txtIdCliente.setText("");
        txtCantidad.setText("");
        txtTotal.setText("$0.00");
        txtFecha.setText("");
        clave = "";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GestionVentas().setVisible(true);
        });
    }
}