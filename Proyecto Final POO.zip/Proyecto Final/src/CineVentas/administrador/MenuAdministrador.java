package CineVentas.administrador;

import CineVentas.login.Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuAdministrador extends JFrame {

    private JPanel menuAdmin;
    private JButton gestionDeUsuariosButton;
    private JButton cerrarSesionButton;
    private JButton gestionDeFuncionesButton;
    private JButton gestionDePeliculasButton;
    private JButton gestionDeVentasButton;


    public MenuAdministrador() {
        setTitle("Menu de Administrador");
        setSize(480, 360);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(menuAdmin);
        setLocationRelativeTo(null);

        gestionDeUsuariosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionUsuarios usuarios = new GestionUsuarios();
                usuarios.setVisible(true);
                setVisible(false);
            }
        });
        gestionDePeliculasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionPeliculas peliculas = new GestionPeliculas();
                peliculas.setVisible(true);
                setVisible(false);
            }
        });
        gestionDeFuncionesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionFunciones funciones = new GestionFunciones();
                funciones.setVisible(true);
                setVisible(false);
            }
        });
        gestionDeVentasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionVentas ventas = new GestionVentas();
                ventas.setVisible(true);
                setVisible(false);
            }
        });
        cerrarSesionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login login = new Login();
                login.setVisible(true);
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MenuAdministrador().setVisible(true);
        });
    }
}
