package CineVentas.administrador;

import CineVentas.baseDatos.conectUsuarios.controlador.Servicio;
import CineVentas.baseDatos.conectUsuarios.modelo.Usuarios;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class GestionUsuarios extends JFrame {
    private JPanel gestionUser;
    private JTextField textUsuario;
    private JPasswordField newPassword1;
    private JTextField textNombre;
    private JTextField textCedula;
    private JTextField textCorreo;
    private JTextField textEdad;
    private JTextField textDireccion;
    private JTextField textTelefono;
    private JTable table1;
    private JButton guardarButton;
    private JButton eliminarButton;
    private JButton regresarAlMenuButton;
    private JComboBox comboBoxCargo;
    private JComboBox comboBoxGenero;
    private JPasswordField newPassword2;
    private JButton actualizarButton;
    private JButton limpiarButton;

    private DefaultTableModel model;
    private String clave;
    private Servicio controlador = new Servicio();
    private Object[] columns = {"ID", "Nombre", "Usuario", "Tipo", "Cédula", "Correo", "Edad", "Género", "Teléfono", "Dirección"};
    private Object[] row = new Object[10];
    private String currentPassword = "";

    public GestionUsuarios() {
        setTitle("Gestión de Usuarios");
        setSize(1024, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(gestionUser);
        setLocationRelativeTo(null);

        // Configurar combobox
        comboBoxCargo.setModel(new DefaultComboBoxModel<>(new String[]{"Cliente", "Funcionario", "Administrador"}));
        comboBoxGenero.setModel(new DefaultComboBoxModel<>(new String[]{"Masculino", "Femenino", "Otro"}));

        obtenerRegistroTabla();

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = table1.getSelectedRow();
                clave = model.getValueAt(i, 0).toString();
                textNombre.setText(model.getValueAt(i, 1).toString());
                textUsuario.setText(model.getValueAt(i, 2).toString());
                comboBoxCargo.setSelectedItem(model.getValueAt(i, 3).toString());
                textCedula.setText(model.getValueAt(i, 4).toString());
                textCorreo.setText(model.getValueAt(i, 5).toString());
                textEdad.setText(model.getValueAt(i, 6).toString());
                comboBoxGenero.setSelectedItem(model.getValueAt(i, 7).toString());
                textTelefono.setText(model.getValueAt(i, 8).toString());
                textDireccion.setText(model.getValueAt(i, 9).toString());
            }
        });

        guardarButton.addActionListener(e -> {
            // Validar que las contraseñas coincidan
            if (!new String(newPassword1.getPassword()).equals(new String(newPassword2.getPassword()))) {
                JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validar que la contraseña no esté vacía al crear
            if (newPassword1.getPassword().length == 0) {
                JOptionPane.showMessageDialog(this, "La contraseña no puede estar vacía", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Usuarios usuarios = new Usuarios(
                    0, // ID temporal
                    textNombre.getText(),
                    textUsuario.getText(),
                    new String(newPassword1.getPassword()),
                    comboBoxCargo.getSelectedItem().toString(),
                    textCedula.getText(),
                    textCorreo.getText(),
                    Integer.parseInt(textEdad.getText()),
                    comboBoxGenero.getSelectedItem().toString(),
                    textTelefono.getText(),
                    textDireccion.getText()
            );

            controlador.insertar(usuarios);
            obtenerRegistroTabla();
        });

        actualizarButton.addActionListener(e -> {
            // Validar que las contraseñas coincidan si se están cambiando
            String password1 = new String(newPassword1.getPassword());
            String password2 = new String(newPassword2.getPassword());

            if (!password1.isEmpty() || !password2.isEmpty()) {
                if (!password1.equals(password2)) {
                    JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // Usar la contraseña actual si no se especifica una nueva
            String passwordFinal = password1.isEmpty() ? currentPassword : password1;

            int id = Integer.parseInt(clave);
            Usuarios usuarios = new Usuarios(
                    id,
                    textNombre.getText(),
                    textUsuario.getText(),
                    passwordFinal,
                    comboBoxCargo.getSelectedItem().toString(),
                    textCedula.getText(),
                    textCorreo.getText(),
                    Integer.parseInt(textEdad.getText()),
                    comboBoxGenero.getSelectedItem().toString(),
                    textTelefono.getText(),
                    textDireccion.getText()
            );
            controlador.actualizar(usuarios);
            obtenerRegistroTabla();
        });

        eliminarButton.addActionListener(e -> {
            int id = Integer.parseInt(clave);
            controlador.eliminar(id);
            obtenerRegistroTabla();
        });

        limpiarButton.addActionListener(e -> limpiarCampos());

        regresarAlMenuButton.addActionListener(e -> {
            MenuAdministrador menu = new MenuAdministrador();
            menu.setVisible(true);
            setVisible(false);
        });
    }

    private void obtenerRegistroTabla() {
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int fila, int columnas) {
                return false;
            }
        };
        model.setColumnIdentifiers(columns);

        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }

        Map<Integer, Usuarios> mapa = controlador.seleccionarTodo();
        for (Map.Entry<Integer, Usuarios> entry : mapa.entrySet()) {
            Usuarios usuarios = entry.getValue();
            row[0] = usuarios.getIdUsuario();
            row[1] = usuarios.getNombre();
            row[2] = usuarios.getUsuario();
            row[3] = usuarios.getTipoUsuario();
            row[4] = usuarios.getCedula();
            row[5] = usuarios.getCorreo();
            row[6] = usuarios.getEdad();
            row[7] = usuarios.getGenero();
            row[8] = usuarios.getTelefono();
            row[9] = usuarios.getDireccion();
            model.addRow(row);
        }

        table1.setModel(model);
        limpiarCampos();
    }

    private void limpiarCampos() {
        textNombre.setText("");
        textUsuario.setText("");
        newPassword1.setText("");
        comboBoxCargo.setSelectedIndex(0);
        textCedula.setText("");
        textCorreo.setText("");
        textEdad.setText("");
        comboBoxGenero.setSelectedIndex(0);
        textTelefono.setText("");
        textDireccion.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GestionUsuarios().setVisible(true);
        });
    }
}