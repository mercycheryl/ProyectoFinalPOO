package CineVentas.modelos;

public class Cliente {
}
