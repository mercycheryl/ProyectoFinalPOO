package CineVentas.modelos;

public class Sala {
}
