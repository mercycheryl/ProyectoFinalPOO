package CineVentas.modelos;

public class Boleto {
}
