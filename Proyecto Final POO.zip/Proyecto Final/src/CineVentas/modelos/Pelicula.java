package CineVentas.modelos;

public class Pelicula {
}
