package CineVentas.modelos;

public class Usuario {
}
