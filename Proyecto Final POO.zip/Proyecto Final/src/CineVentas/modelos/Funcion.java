package CineVentas.modelos;

public class Funcion {
}
