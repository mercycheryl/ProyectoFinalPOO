package CineVentas.usuario;

import CineVentas.baseDatos.conectPeliculas.modelo.Conexion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class VerFuncionesDisponibles extends JFrame {
    private JPanel JPanel1;
    private JTable table1;
    private JScrollPane jscroll;
    private DefaultTableModel model;

    public VerFuncionesDisponibles() {
        setTitle("FUNCIONES DISPONIBLES");
        setSize(850, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(JPanel1);
        setLocationRelativeTo(null);

        // Configurar el modelo de la tabla
        model = new DefaultTableModel();
        table1.setModel(model);

        // Agregar columnas al modelo
        model.addColumn("ID");
        model.addColumn("Título");
        model.addColumn("Categoría");
        model.addColumn("Duración");
        model.addColumn("Sinopsis");
        model.addColumn("Clasificación");
        model.addColumn("Estado");

        // Cargar datos de la base de datos
        cargarDatosPeliculas();
    }

    private void cargarDatosPeliculas() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Conexion conexion = new Conexion();
            conn = conexion.conectar();

            // Consulta SQL para obtener las películas
            String sql = "SELECT id_pelicula, titulo, categoria, duracion, sinopsis, clasificacion, estado FROM peliculas";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            // Limpiar la tabla antes de agregar nuevos datos
            model.setRowCount(0);

            // Llenar la tabla con los datos de la consulta
            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id_pelicula"),
                        rs.getString("titulo"),
                        rs.getString("categoria"),
                        rs.getInt("duracion"),
                        rs.getString("sinopsis"),
                        rs.getString("clasificacion"),
                        rs.getString("estado")
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VerFuncionesDisponibles().setVisible(true);
        });
    }
}