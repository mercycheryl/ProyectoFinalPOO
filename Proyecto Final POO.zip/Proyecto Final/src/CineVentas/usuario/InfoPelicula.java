package CineVentas.usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import CineVentas.baseDatos.conectPeliculas.controlador.Servicio;
import CineVentas.baseDatos.conectPeliculas.modelo.Peliculas;
import java.util.Map;

public class InfoPelicula extends JFrame {
    private JPanel panel1;
    private JPanel imagen;  // Este será el panel donde mostraremos la imagen
    private JLabel titulo;
    private JLabel categoria;
    private JLabel duracion;
    private JTextArea sinopsis;
    private JLabel clasificacion;
    private JLabel estado;
    private JButton regresarAlDirectorioButton;
    private JButton comprarButton;

    private String nombrePelicula;
    private static final String IMAGE_FOLDER = "src/CineVentas/images/";

    public InfoPelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;

        setTitle("COMPRA DE BOLETOS - " + nombrePelicula);
        setSize(720, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);

        // Configurar el panel de imagen
        imagen.setLayout(new BorderLayout());
        cargarImagenPelicula();

        // Configurar los demás componentes
        titulo.setText(nombrePelicula);
        cargarDatosPelicula();

        regresarAlDirectorioButton.addActionListener(e -> {
            new ComprarBoletos().setVisible(true);
            dispose();
        });

        comprarButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Comprando boletos para: " + nombrePelicula,
                    "Compra de Boletos", JOptionPane.INFORMATION_MESSAGE);
        });
    }

    private void cargarImagenPelicula() {
        try {
            // Buscar la imagen en el directorio (puede ser jpg, png o jpeg)
            File imageFile = findImageFile(nombrePelicula);

            if (imageFile != null && imageFile.exists()) {
                BufferedImage originalImage = ImageIO.read(imageFile);

                // Redimensionar la imagen para que se ajuste al panel
                int panelWidth = imagen.getWidth();
                int panelHeight = imagen.getHeight();

                if (panelWidth <= 0) panelWidth = 200; // Valor por defecto si no tiene tamaño aún
                if (panelHeight <= 0) panelHeight = 300; // Valor por defecto

                Image scaledImage = originalImage.getScaledInstance(
                        panelWidth, panelHeight, Image.SCALE_SMOOTH);

                JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
                imagen.removeAll(); // Limpiar el panel antes de añadir la nueva imagen
                imagen.add(imageLabel, BorderLayout.CENTER);
                imagen.revalidate();
                imagen.repaint();
            } else {
                // Mostrar un placeholder si no se encuentra la imagen
                JLabel noImageLabel = new JLabel("Imagen no disponible");
                noImageLabel.setHorizontalAlignment(JLabel.CENTER);
                imagen.add(noImageLabel, BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JLabel errorLabel = new JLabel("Error al cargar imagen");
            errorLabel.setHorizontalAlignment(JLabel.CENTER);
            imagen.add(errorLabel, BorderLayout.CENTER);
        }
    }

    private File findImageFile(String imageName) {
        File folder = new File(IMAGE_FOLDER);
        File[] files = folder.listFiles((dir, name) ->
                name.toLowerCase().startsWith(imageName.toLowerCase()) &&
                        (name.toLowerCase().endsWith(".jpg") ||
                                name.toLowerCase().endsWith(".png") ||
                                name.toLowerCase().endsWith(".jpeg")));

        return (files != null && files.length > 0) ? files[0] : null;
    }

    private void cargarDatosPelicula() {
        // Crear una instancia del servicio
        CineVentas.baseDatos.conectPeliculas.controlador.Servicio servicio = new CineVentas.baseDatos.conectPeliculas.controlador.Servicio();

        // Obtener todas las películas
        Map<Integer, CineVentas.baseDatos.conectPeliculas.modelo.Peliculas> peliculas = servicio.seleccionarTodo();

        // Buscar la película por su título
        CineVentas.baseDatos.conectPeliculas.modelo.Peliculas peliculaSeleccionada = null;
        for (CineVentas.baseDatos.conectPeliculas.modelo.Peliculas pelicula : peliculas.values()) {
            if (pelicula.getTitulo().equalsIgnoreCase(nombrePelicula)) {
                peliculaSeleccionada = pelicula;
                break;
            }
        }

        // Si encontramos la película, cargamos sus datos
        if (peliculaSeleccionada != null) {
            // El título ya lo establecimos en el constructor
            categoria.setText("Categoría: " + peliculaSeleccionada.getCategoria());
            duracion.setText("Duración: " + peliculaSeleccionada.getDuracion() + " minutos");
            sinopsis.setText(peliculaSeleccionada.getSinopsis());
            clasificacion.setText("Clasificación: " + peliculaSeleccionada.getClasificacion());
            estado.setText("Estado: " + peliculaSeleccionada.getEstado());

            sinopsis.setEditable(false);
            sinopsis.setBackground(panel1.getBackground());  // Hace que el fondo coincida con el panel
        } else {
            // Si no encontramos la película, mostramos un mensaje
            JOptionPane.showMessageDialog(this,
                    "No se encontraron datos para la película: " + nombrePelicula,
                    "Error", JOptionPane.ERROR_MESSAGE);
            dispose(); // Cerramos esta ventana si no hay datos
            new ComprarBoletos().setVisible(true); // Volvemos al directorio
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Esto es solo para pruebas, en uso normal se llamará con el constructor que recibe el nombre
            new InfoPelicula("Nombre de Prueba").setVisible(true);
        });
    }
}