package CineVentas.usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class ComprarBoletos extends JFrame {
    private JPanel panel1;
    private JScrollPane jscroll;
    private JButton regresarAlMenuButton;
    private JPanel imagePanel;

    public ComprarBoletos() {
        setTitle("COMPRA DE BOLETOS");
        setSize(720, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel1);
        setLocationRelativeTo(null);

        imagePanel = new JPanel();
        imagePanel.setLayout(new GridLayout(0, 3, 10, 10));
        imagePanel.setBorder(new EmptyBorder(10, 5, 10, 5));
        jscroll.setViewportView(imagePanel);

        loadImagesFromFolder();

        regresarAlMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MenuUsuario m = new MenuUsuario();
                m.setVisible(true);
                setVisible(false);
            }
        });
    }

    private void loadImagesFromFolder() {
        String imageFolderPath = "src/CineVentas/images/";
        File folder = new File(imageFolderPath);

        if (folder.exists() && folder.isDirectory()) {
            File[] listOfFiles = folder.listFiles((dir, name) ->
                    name.toLowerCase().endsWith(".jpg") ||
                            name.toLowerCase().endsWith(".png") ||
                            name.toLowerCase().endsWith(".jpeg"));

            if (listOfFiles != null && listOfFiles.length > 0) {
                for (File file : listOfFiles) {
                    try {
                        BufferedImage originalImage = ImageIO.read(file);
                        int width = 160;
                        int height = (int) (width * (4.0/3.0));

                        Image scaledImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                        ImageIcon imageIcon = new ImageIcon(scaledImage);

                        JPanel singleImagePanel = new JPanel(new BorderLayout());
                        singleImagePanel.setBackground(Color.WHITE);
                        singleImagePanel.setPreferredSize(new Dimension(width, height + 20));

                        JLabel imageLabel = new JLabel(imageIcon);
                        imageLabel.setHorizontalAlignment(JLabel.CENTER);

                        String imageName = file.getName()
                                .replace(".jpg", "")
                                .replace(".png", "")
                                .replace(".jpeg", "");

                        JLabel titleLabel = new JLabel(imageName, JLabel.CENTER);
                        titleLabel.setFont(new Font("Arial", Font.PLAIN, 12));

                        singleImagePanel.add(imageLabel, BorderLayout.CENTER);
                        singleImagePanel.add(titleLabel, BorderLayout.SOUTH);

                        // Agregar MouseListener al panel de la imagen
                        singleImagePanel.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                // Abrir nueva ventana con el nombre de la imagen
                                abrirVentanaPelicula(imageName);
                            }
                        });

                        // Hacer que los componentes hijos también sean clickeables
                        imageLabel.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                abrirVentanaPelicula(imageName);
                            }
                        });

                        titleLabel.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                abrirVentanaPelicula(imageName);
                            }
                        });

                        imagePanel.add(singleImagePanel);
                    } catch (IOException e) {
                        System.err.println("Error al cargar imagen: " + file.getName());
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron imágenes en la carpeta",
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "La carpeta de imágenes no existe: " + folder.getAbsolutePath(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        imagePanel.revalidate();
        imagePanel.repaint();
    }

    private void abrirVentanaPelicula(String nombrePelicula) {
        // Crea y muestra la ventana InfoPelicula con el nombre de la película
        InfoPelicula infoPelicula = new InfoPelicula(nombrePelicula);
        infoPelicula.setVisible(true);

        // Cierra la ventana actual
        this.setVisible(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ComprarBoletos().setVisible(true);
        });
    }
}